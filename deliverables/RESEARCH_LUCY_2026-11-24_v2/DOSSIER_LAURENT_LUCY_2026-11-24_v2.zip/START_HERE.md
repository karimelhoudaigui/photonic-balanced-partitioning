# Dossier Laurent — Lucy via TGCC

Commencer par docs/LUCY_TGCC.md et paper/main.pdf.
Le dossier contient le code Python, le pilote figé, deux fichiers de tests
matériels locaux, les sources de l'article et les données sélectionnées.
Il n'inclut pas tout l'historique Git ni toutes les campagnes antérieures.
Le dépôt complet reste la référence pour les 505 tests et la réconciliation :
https://github.com/karimelhoudaigui/photonic-balanced-partitioning

Installation locale : suivre README.md. Contrôle propre à ce dossier :
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python -m pytest tests/test_hardware_offline.py tests/test_lucy_tgcc.py -q

Sur TGCC, utiliser les bibliothèques du conteneur ccc-quantum sans les remplacer
par le lock local. PYTHONPATH=src suffit pour charger le code du dossier.
La commande environment et la préparation plan sont hors ligne.
L'acquisition exige une autorisation opérateur distincte et les contrôles réels.
Aucun résultat QPU n'est inclus ; tous les counts locaux sont synthétiques.
L'absence de .git est enregistrée comme métadonnée de commit indisponible.
Conserver le manifeste de ce dossier pour identifier son commit source.
